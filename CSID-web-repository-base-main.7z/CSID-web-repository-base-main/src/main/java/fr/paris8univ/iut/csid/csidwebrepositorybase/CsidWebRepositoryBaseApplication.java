package fr.paris8univ.iut.csid.csidwebrepositorybase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CsidWebRepositoryBaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(CsidWebRepositoryBaseApplication.class, args);
        System.out.println("Hello World !");
    }

}
